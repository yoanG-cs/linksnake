#include <iostream>
using namespace std;

int main()
{
    int n, a, b, c;
    cout << "Write a three digit whole number: ";
    cin >> n;
    a = n/100;
    b  = (n/10) % 10;
    c = n % 10;
    cout << "The sum of the numbers: " << a + b + c << endl;
    cout << "The number in revers: " << c << b << a << endl;

}
