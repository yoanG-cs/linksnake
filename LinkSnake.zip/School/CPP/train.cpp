#include <iostream>
 using namespace std;

 int main() 
 {

    int num, a, b, c, d, e, f;
    cout << "Enter a six digit positive whole number: ";
    cin >> num;
    
    a = num/100000;
    b = (num/10000) % 10;
    c = (num/1000) % 10;
    d = (num/100) % 10;
    e = (num/10) % 10;
    f = num % 10;

    cout << "The sum of all  the numbers ids: " << a+b+c+d+e+f << endl;
    cout << "The tenths of the numbers: " << b << endl;
    cout << "The number in reverse: " << f << e << d << c << b << a << endl;
    cout << "The margin of the thousands and units: " << d - a << endl;
    cout << "The product of the tenhundrets and units: " << f * a << endl;
 }
 // Въведете цяло полужително 6 цифрено число.;
 // Задачата да извежда сбора на цифрите на числото;
 // да извежда цифрата на десетиците; числото записано в обратен ред; 
 // разликата на цифрата на хиледните с цифрата на единиците;
 //  произведението на стохиледната да се умножи с тази на единиците;