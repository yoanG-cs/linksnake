#include <iostream>
 using namespace std;

 int main() {
    int num;
    cout << "Give me a four digit whole number: ";
    cin >> num;

    int divider = 1;

    for (int i= 0; i < 4; i++)
    {
        cout << (num/divider) % 10;
        divider *= 10;
    }
    return 0;
 }